const ticker = document.getElementById("ticker-text");

const apiKey = "AIzaSyDiGFfVS5wDvbMxCZ2r_KSLiFQC8orGS4c";
const spreadsheetId = "1SAkkN7O4k2OYIOTAY9Kpv3LPYtHAkBvmYlA1vKAjOQw";
const announcementRange = "Sheet2!F1";

let tickerItems = [];
let currentTickerIndex = 0;

// Generic function to load a sheet into a tile-content area
async function loadSheet(range, containerId) {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}?key=${apiKey}`;
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();

        if (!data.values) return;

        const container = document.getElementById(containerId + "-content");
        container.innerHTML = "";

        const table = document.createElement("table");
        const thead = document.createElement("thead");
        const tbody = document.createElement("tbody");

        data.values.forEach((row, i) => {
            const tr = document.createElement("tr");
            row.forEach(cell => {
                const cellEl = document.createElement(i === 0 ? "th" : "td");
                cellEl.textContent = cell;
                tr.appendChild(cellEl);
            });
            i === 0 ? thead.appendChild(tr) : tbody.appendChild(tr);
        });

        table.appendChild(thead);
        table.appendChild(tbody);
        container.appendChild(table);
    } catch (error) {
        console.error(`Could not fetch data for ${containerId}:`, error);
    }
}

// Function to check and display announcements in Tile 2
async function checkAndDisplayAnnouncement() {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${announcementRange}?key=${apiKey}`;
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        
        const annContainer = document.getElementById("tile2-content");
        annContainer.innerHTML = "";

        if (data.values && data.values.length > 0 && data.values[0][0]) {
            const announcementText = data.values[0][0];
            const announcementDiv = document.createElement("div");
            announcementDiv.style.padding = "20px";
            announcementDiv.style.textAlign = "center";
            announcementDiv.style.fontSize = "16px";
            announcementDiv.style.color = "#2c3e50";
            announcementDiv.style.fontWeight = "bold";
            announcementDiv.innerHTML = `📢 <strong>ANNOUNCEMENT:</strong><br><br>${announcementText}`;
            annContainer.appendChild(announcementDiv);
        }
    } catch (error) {
        console.error("Error loading announcement:", error);
    }
}

// Function to fetch ticker items and start the cycle
async function fetchAndCycleTickerItems() {
    const tickerRange = "Sheet1!A1:E20";
    const tickerUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${tickerRange}?key=${apiKey}`;
    
    try {
        const res = await fetch(tickerUrl);
        if (!res.ok) {
            throw new Error(`HTTP error! status: ${res.status}`);
        }
        const data = await res.json();
        
        if (!data.values || data.values.length <= 1) {
            ticker.textContent = "⚠️ No data found in sheet";
            tickerItems = [];
            return;
        }

        const rows = data.values;
        rows.shift(); // remove header

        tickerItems = rows.map(r => {
            const [code, ...details] = r;
            // Join all cells to create a full paragraph
            return `${code || ""} ${details.join(" ")}`;
        });

        // Start the ticker display cycle
        displayNextTickerItem();

    } catch (err) {
        console.error("Error loading ticker:", err);
        ticker.textContent = "⚠️ Failed to load data";
        tickerItems = [];
    }
}

// Function to display the next ticker item
function displayNextTickerItem() {
    if (tickerItems.length === 0) return;

    // Use a single child div for the ticker content
    let tickerContentDiv = document.getElementById("ticker-content-div");
    if (!tickerContentDiv) {
        tickerContentDiv = document.createElement("div");
        tickerContentDiv.id = "ticker-content-div";
        tickerContentDiv.classList.add("ticker-popup");
        ticker.appendChild(tickerContentDiv);
    }

    // Hide the current text before updating
    tickerContentDiv.classList.remove("show");
    
    // Use a timeout to ensure the transition runs
    setTimeout(() => {
        // Set the new text content
        tickerContentDiv.textContent = tickerItems[currentTickerIndex];
        // Show the new text with a transition
        tickerContentDiv.classList.add("show");

        // Cycle to the next item
        currentTickerIndex = (currentTickerIndex + 1) % tickerItems.length;
    }, 600); // Wait for the "hide" transition to complete

    // Set up the interval for the next update
    setTimeout(displayNextTickerItem, 5000); // 5s delay before showing next
}

// Initial loads
document.addEventListener('DOMContentLoaded', () => {
    loadSheet("Sheet3!A1:Z", "tile1");  // Rights Issue
    loadSheet("Sheet2!A1:E20", "tile3"); // Dividends
    checkAndDisplayAnnouncement();
    fetchAndCycleTickerItems();
});

// Set up intervals for refresh
setInterval(checkAndDisplayAnnouncement, 30000);
setTimeout(() => {
    window.location.reload();
}, 150000); // Reload page every 3 minutes